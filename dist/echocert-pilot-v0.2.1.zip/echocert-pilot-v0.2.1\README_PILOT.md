# EchoCert — Pilot Package

EchoCert is a deterministic forensic audit engine for LLM outputs.

It records prompts and outputs as immutable artifacts, seals them cryptographically,
and produces deterministic diffs that prove when and how outputs change over time.

## What this pilot demonstrates

- Deterministic receipt generation
- Cryptographic sealing (SHA-256)
- Tamper detection
- Deterministic diffs
- End-to-end verification
- Automated tests

## Non-goals

EchoCert does not:
- judge correctness
- evaluate safety or alignment
- inspect model internals
- infer intent

It provides evidence, not opinions.

## Requirements

- Python 3.10+
- Bash (Git Bash on Windows is sufficient)

## Time to validate

Approximately 5 minutes.
