# EchoCert — Quickstart

## 1. Run all tests

```bash
./tests/run_all.sh
